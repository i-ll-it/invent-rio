package principal;

import entidade.*;
import principal.Principal;

public class ProjectTester {
    Principal teste = new Principal();


}
