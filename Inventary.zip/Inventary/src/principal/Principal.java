package principal;

import entidade.Produto;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        int maxSize;
        Scanner sc = new Scanner(System.in);
        while(true) {
            try
            System.out.println("Insira o número de produtos que você gostaria de adicionar\nInsira 0 (zero) se não quiser adicionar produtos");
            maxSize = sc.nextInt();
            if (maxSize < 0) {
                System.out.println("Valor incorreto inserido");
            } else {break;}
        }

        System.out.println("Insira o nome do produto no formato 'CD + Nome do Grupo + Nome do Álbum/Single': ");
        String tempName = sc.nextLine();
        System.out.println("Insira a quantidade desse CD no estoque");
        int tempQty = sc.nextInt();
        System.out.println("Insira o código do CD: ");
        int tempNumber = sc.nextInt();
        System.out.println("Insira o preço do CD: ");
        double tempPrice = sc.nextDouble();

        Produto produto1 = new Produto(tempNumber, tempQty, tempPrice, tempName);

        sc.nextLine();

        System.out.println("Insira o nome do produto no formato 'CD + Nome do Grupo + Nome do Álbum/Single': ");
        tempName = sc.nextLine();
        System.out.println("Insira a quantidade desse CD no estoque");
        tempQty = sc.nextInt();
        System.out.println("Insira o código do CD: ");
        tempNumber = sc.nextInt();
        System.out.println("Insira o preço do CD: ");
        tempPrice = sc.nextDouble();
        Produto produto2 = new Produto(tempNumber, tempQty, tempPrice, tempName);
        produto2.setAtivo(false);



        //Construtor criado para instanciar os objetos da classe Produto mais rapidamente
        Produto produto3 = new Produto(152, 3, 20.00, "CD ZB1 YOUTH IN THE SHADE");
        Produto produto4 = new Produto(153, 3, 20.00, "CD ZB1 MELTING POINT");
        Produto produto5 = new Produto(154, 3, 20.00, "CD ZB1 YOU HAD ME AT HELLO");
        Produto produto6 = new Produto(155, 3, 20.00, "CD ZB1 CINEMA PARADISE");

        String detalhe_produto1 = produto1.toString();
        String detalhe_produto2 = produto2.toString();
        String detalhe_produto3 = produto3.toString();
        String detalhe_produto4 = produto4.toString();
        String detalhe_produto5 = produto5.toString();
        String detalhe_produto6 = produto6.toString();

        System.out.println(detalhe_produto1 + "\n\n" + detalhe_produto2 + "\n\n" + detalhe_produto3 + "\n\n" + detalhe_produto4 + "\n\n" + detalhe_produto5 + "\n\n" + detalhe_produto6);
    }
}
