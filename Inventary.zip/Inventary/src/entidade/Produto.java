package entidade;

public class Produto {

    //Declarações de campo de instância
    private int codigo, quantidade;
    private double preco;
    private String nome;

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    boolean ativo = true;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Produto() {
    }

    public double getInventoryValue() {
        return quantidade * preco;
    }

    public Produto(int codigo, int quantidade, double preco, String nome) {
        this.codigo = codigo;
        this.quantidade = quantidade;
        this.preco = preco;
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Número do Item: " + codigo +
                "\nNome: " + nome +
                "\nQuantidade em estoque: " + quantidade +
                "\nPreço: " + preco +
                "\nValor do Estoque: " + getInventoryValue() +
        "\nStatus do Produto: " + (this.ativo ? "Ativo" : "Descontinuado");
    }
}
